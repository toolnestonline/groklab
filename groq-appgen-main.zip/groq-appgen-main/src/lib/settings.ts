export const MAINTENANCE_MODE = false;
export const MAINTENANCE_GENERATION = false;
export const MAINTENANCE_USE_VANILLA_MODEL = false;
